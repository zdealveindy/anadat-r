/* Neutral community simulation, based on: 
   Bell. 2003. Proc. R. Soc. Lond. B. 270: 2531-2542 
   
   With modifications to accomodate environmental filtering based on a single
   niche gradient.

   Implemented by Tyler Smith, April 2008, and (to be) released under the
   conditions of the GNU GPL version 3.

   The model is described in the caption to figure 3, and also in Bell. 2000.
   Am. Nat. 155: 606-617. The non-neutral components are my additions. Universe
   is defined by an M * M square grid.

     M = sqrt of number of grid cells
     K = cell carrying capacity
     S = species in the universe
     dv = mortality vector - prob. of death per species per generation per cell
     bv = birth rate vect. - prob. of birth per species per generation per cell
     u = migration rate per newborn
     m = immigration rate into marginal cells per species

     ef = environmental filter - vector of probabilities that a recruit from a
          given species will successfully establish in a given location (usually
          1)

     fec = fecundity, number of birth attempts per time period per individual

   bv and dv are fixed in neutral communities. In niche-structured communities
   these values are calculated per species per cell, based on the optimal
   condition of the species and the environmental condition of the cell. Species
   in their optimal environment have maximum birth rate and minimum death rate.

   After births and immigration, any cell with a population greater than K is
   subjected to culling, whereby randomly selected individuals are removed from
   the cell until the population is reduced to K. 

   Bell did not specify an algorithm for migration. I use a random walk: if an
   individual migrates, it moves one step in a random direction. It remains
   there with probability 1 - u. If it doesn't stay there, it moves again to any
   of the adjacent 8 cells, until it 'fails' to migrate any further.

   data structures:

   The universe is a single vector. This is due to the requirement that
   variables passed from R to C must be vectors, and matrices and
   higher-dimension arrays must be converted to vectors prior to passing them to
   C. To facilitate this, the array is allocated in R, and then rebuilt into
   appropriate matrices in R after the function returns. Actually, all
   parameters and data structures are initialised in R.

   What we need to know for the C code is that the vector is arranged as a
   repeating pattern of S integers, representing the abundances of each of the S
   species in each cell. i.e., pop[0] is the abundance of species 1 in cell one.
   pop[S] is the abundance of species one in cell 2, and pop[S * (n - 1)] is the
   abundance of species one in cell n. Similarly, pop[S * (n - 1) + j], where j
   < S, is the abundance of species j in cell n.

   The cells are arranged in a square of dimensions M * M. There are therefore M
   * S elements in each row and each column. Moving to an adjacent column
   therefore requires adding or subtracting S to the element index. Moving to an
   adjacent row requires adding or subtracting M * S to the element index.
   Newborns that disperse beyond the edges of the grid are lost.

   Given that i is the current position in the overall array [zero offset]: the
   species number is i % S; the cell number is i / S (integer division); column
   number is cell number % M. Row number is cell number / M.

   functions:

   main loop: 
       iterate over outer array
           iterate over value of each cell in the inner array
	     if (birth) migrate-or-stay
             if (death) -= 1
   add newborns to population
   immigrate
   cull

   migrate-or-stay:
       if (fail to migrate) + 1 to current cell in the newborn array
       else: pick a new cell, migrate-or-stay

   add-newborns:
       iterate over newborn array
           iterate over cells in the inner array
	     add value of cell to corresponding value in main array

   immigrate:
       iterate over marginal cells
           iterate over value of each cell in the inner array
	     if (immigrate) += 1

   cull:
      iterate over outer array
          sum values of inner array = SA
	  if (sum values of inner array > K)
	    for (i = SA; i > K; i--)
	      select a random number between 1 and i
	        iterate over cells until cumsum > i
		  cell value-- */

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <R.h>
#include <R_ext/Utils.h>

/* This macro is used as a convenience in the migrate function, and is useful
   only when i, S, and M are integers in the current scope */
#define COL (((i - i % S)/S) % (M))


void smith08b
(int *M, int *K, int *S, int *pop, int *nb, double *u, double *dv, double *bv, double *m, int *t, double *ef, int *fec) {

    GetRNGstate(); 		/* Initialize the R random number generator */
    void migrate(int *nb, int i, int CELLS, double u, int M, int S, double *ef);

    int i, j, g, tmp, tmp2, cull, CELLS;
    srand(time(NULL));

    CELLS = (*M) * (*M) * (*S);

    for (i = 0; i < CELLS; i++)	{ /* Initialize arrays */
	nb[i] = 0;
    }

    for (g = 0; g < *t; g ++) { /* time */
	if (g % 100 == 0)
	/* Rprintf("Time = %i\n", g); */
	R_CheckUserInterrupt();

	for (i = 0; i < (*S) * (*M); i++) { /* immigrate into marginal cells: top row */
	    if (unif_rand() < *m)
			pop[i]++;
	}
	
	for (i = CELLS - (*S) * (*M); i < CELLS; i++) { /* immigrate into marginal cells: bottom row */
	    if (unif_rand() < *m)
			pop[i]++;
	}
	
	for (i = (*M) * (*S); i < CELLS - ((*M) * (*S)); i += ((*M) * (*S)) ) { /* immigrate into marginal cells: first
										   column */
	    for (j = i; j < i + *S; j++)
		if (unif_rand() < *m)
		    pop[j]++;
	}

	for (i = 2 * *M * *S; i < CELLS; i += *M * *S) { /* immigrate into marginal cells: last column */
	    for (j = i - *S; j < i; j++)
		if (unif_rand() < *m)
		    pop[j]++;
	}

	for (i = 0; i < CELLS; i++) { /* birth loop */
	    tmp = 0;
	    while (tmp < pop[i]) { /* birth loop */
		for (j = 0; j < *fec; j++)
		    if (unif_rand() < bv[i]) { /* Rprintf("migrating from i = %i => ", i ); */
			migrate(nb, i, CELLS, *u, *M, *S, ef);
		    }
		/* 			printf(":\n"); */
		tmp++;
	    }
	    
	    j = 0;
	    tmp = 0;
	    while (j < pop[i]) { /* death loop */
		if (unif_rand() < dv[i])
		    tmp++;
		j++;
	    }
	    pop[i] -= tmp;
	}
	
	for (i = 0; i < CELLS; i++) {	/* add newborns */
	    pop[i] += nb[i];
	    nb[i] = 0;
	}
	
	for (i = 0; i < CELLS; i += *S)	{ /* cull */
	    tmp  = 0;
	    for (j = i; j < (i + *S); j++)
		tmp += pop[j];
	    
	    while (tmp > *K) {
		/* Rprintf("Culling at i = %i, tmp = %i\n", i, tmp); */
		cull = (rand() % tmp) + 1;
		tmp2 = 0;
		j = i;
		while (j < (i + *S)) { 
		    tmp2 += pop[j];			
		    /* Rprintf(" entering inner while, cull = %i, tmp2 = %i, j = %i, pop[j] = %i\n", cull, tmp2, j,
		       pop[j]); */
		    if (tmp2 >= cull) {
			pop[j]--;
			tmp--;
			/* Rprintf("    ...culled, j = %i, pop[j] = %i, tmp = %i\n", j, pop[j], tmp); */
			break;
		    }
		    j++;
		    /* Rprintf("...not culled\n"); */
		}
	    }
	}
    }

    PutRNGstate();		/* cleanup the R random number generator */
}

void migrate(int *nb, int i, int CELLS, double u, int M, int S, double *ef) {
    int start_col, theta;

    start_col = COL;

    if (unif_rand() > u) {
	if (unif_rand() < ef[i])
	    nb[i]++;
	/* 	Rprintf("to i = %i\n", i); */
	return;
    }

    theta = rand() % 12;

    /* This is a faster implementation of the standard sin, cos calculations */
    switch (theta) {
    case 0 :
    case 1 :
	i -= S;
	break;
    case 2 :
    case 3 :
	i += S;
	break;
    case 4 :
    case 5 :
	i += S * M;
	break;
    case 6 :
    case 7 :
	i -= S * M;
	break;
    case 8 :
	i += S * M - S;
	break;
    case 9 :
	i += S * M + S;
	break;
    case 10 :
	i -= S * M + S;
	break;
    case 11 :
	i -= S * M - S;
	break;
    default :
	Rprintf("something wrong in the migrate function!\n");
    }

    /* xi = cos(theta); yi = sin(theta); */
    /* sin and cos are expensive transcendentals. This would likely be faster if we used the equivalent from a uniform
       distribution: 1/6 chance for x or y but not both to increase or decrease by 1, 1/12 chance for any of the four
       possible changes in both directions at once. */
    
/*     if (xi >= 0.5) 		/\* moving left and right *\/ */
/* 	i += S; */
/*     else if (xi < -0.5) */
/* 	i -= S; */

/*     if (yi >= 0.5)		/\* moving up and down *\/ */
/* 	i -= S * M; */
/*     else if (yi < -0.5) */
/* 	i += S * M; */


    /* Catch migrators wrapping around the grid */
    if (i < 0 || i >= CELLS || abs(COL - start_col) > 1) {
	/*  	Rprintf("... migrator lost!\n"); */
	return;
    } else
	migrate(nb, i, CELLS, u, M, S, ef);
}
		
