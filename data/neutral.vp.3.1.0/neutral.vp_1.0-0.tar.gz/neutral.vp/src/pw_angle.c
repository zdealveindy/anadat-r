#include <R.h>
#include <math.h>

void pwangle(double *X, double *Y, int *L, double *res) {
    int i, j, index = 0;

    for (i = 0; i < ((*L) - 1); i++)
	for (j = i + 1; j < *L; j++)
	    res[index++] = atan((Y[i] - Y[j])/(X[i] - X[j])) * (180/M_PI);
		
}
