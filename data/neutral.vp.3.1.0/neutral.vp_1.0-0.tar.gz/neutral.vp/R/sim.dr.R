`sim.dr` <-
function(sim, snap = length(sim$snaps), fact = 4, I = 1, space = c("X", "Y"), habitat.list = NULL, log = FALSE) {
  if (is.character(snap))
    snap <- which(names(sim$snaps) == snap)
  
  ind <- sim.cut(sim, fact)
  
  Y <- census(sim, snap)[ind,]
  X <- list()
  if(is.null(habitat.list)) {
    X[[1]] <- as.vector(sim$p$habitat)[ind]
  }  else {
    X[[1]] <- as.vector(habitat.list$grad)[ind]
    X[[2]] <- as.vector(habitat.list$hump)[ind]
    X[[3]] <- as.vector(habitat.list$hump4)[ind]
    X[[4]] <- as.vector(habitat.list$rand)[ind]
  }
  
  W <- sim$coords[ind, space]
  Wd <- as.vector(dist(W))
  
  if (log)
    Wd <- log(Wd)
  
  Yd <- dist(decostand(Y, method = "hellinger"))
    
  if(length(X) > 1) {
    r.sq <- matrix(NA, nrow = 4, ncol = 7)
    row.names(r.sq) <- c("grad", "hump", "hump4", "rand")
    
    p.vals <- matrix(NA, nrow = 4, ncol = 6)
    row.names(p.vals) <- c("grad", "hump", "hump4", "rand")
  } else {
    r.sq <- matrix(NA, nrow = 1, ncol = 7)
    p.vals <- matrix(NA, nrow = 1, ncol = 6)
  }
  
  colnames(r.sq) <- c("abc", "ab", "bc", "a", "b", "c", "d")
  colnames(p.vals) <- c("abc", "ab", "bc", "a", "b", "c")
  
  for (j in seq_along(X)){
    
    Xd <- as.vector(dist(X[[j]]))
    
    lm.abc <- lm(Yd ~ Xd + Wd)
    lm.ab <- lm(Yd ~ Xd)
    lm.bc <- lm(Yd ~ Wd)
    lm.wx <- lm(Wd ~ Xd)
    lm.wxr <- resid(lm.wx)
    lm.xw <- lm(Xd ~ Wd)
    lm.xwr <- resid(lm.xw)
    lm.a <- lm(resid(lm.bc) ~ lm.xwr)
    lm.c <- lm(resid(lm.ab) ~ lm.wxr)
    
    abc <- summary(lm.abc)$adj.r.squared
    ab <- summary(lm.ab)$adj.r.squared
    bc <- summary(lm.bc)$adj.r.squared
    a <- abc - bc
    c <- abc - ab
    b <- abc - a - c
    d <- 1 - abc
    
    perm.mat <- matrix(NA, nrow = I, ncol = 6)
    colnames(perm.mat) <- c("abc", "ab", "bc", "a", "b", "c")
    
    for(i in 1:I){
      perm.index <- sample(1:nrow(Y))
      Yd.tmp <- as.dist(as.matrix(Yd)[perm.index,perm.index])
      
      YX <- lm(Yd.tmp ~ Xd)
      YW <- lm(Yd.tmp ~ Wd)
      
      perm.mat[i, 1] <- summary(lm(Yd.tmp ~ Xd + Wd))$adj.r.squared
      perm.mat[i, 2] <- summary(YX)$adj.r.squared
      perm.mat[i, 3] <- summary(YW)$adj.r.squared
      perm.mat[i, 4] <- summary(lm(resid(YW) ~ lm.xwr))$adj.r.squared
      perm.mat[i, 6] <- summary(lm(resid(YX) ~ lm.wxr))$adj.r.squared
      perm.mat[i, 5] <- perm.mat[i, 2] - perm.mat[i, 4]
    }
    
    p.vals[j,] <- c(abc = sum(perm.mat[, 1] >= abc)/(I + 1),
                    ab =  sum(perm.mat[, 2] >=  ab)/(I + 1),
                    bc =  sum(perm.mat[, 3] >=  bc)/(I + 1), 
                    a =   sum(perm.mat[, 4] >=   a)/(I + 1),
                    b =   sum(perm.mat[, 5] >=   b)/(I + 1),
                    c =   sum(perm.mat[, 6] >=   c)/(I + 1))
    
    
    r.sq[j,] <- c(abc = abc, ab = ab, bc = bc, a = a, b = b, c = c, d = d)
  }
  
  return(list(r.square = r.sq, p = p.vals))
}
