`dmgram` <-
function (species.d, space.xy, breaks, nclass, stepsize, nperm = 1000, trace = FALSE, alpha = c(0, 45, 90, 135))
{
  Nitems <- nrow(space.xy)
  
  space.d <- dist(space.xy)
  space.ang <- pw.angle(space.xy)
  species.d <- as.vector(species.d)
  space <- as.vector(space.d)

  ang.breaks <- numeric(length(alpha))

  for (i in 1:(length(alpha) - 1))
    ang.breaks[i] <- mean(alpha[i:(i+1 )])

  ang.breaks[length(ang.breaks)] <- mean(c(180 + alpha[1], alpha[length(alpha)]))

  space.ang[space.ang > ang.breaks[length(ang.breaks)]] <- space.ang[space.ang > ang.breaks[length(ang.breaks)]] - 180
  
  if (missing(breaks)) {
    if (missing(nclass)) {
      if (missing(stepsize)) {
        nclass <- round(1 + 3.3 * log10(length(space.d))/length(alpha))
        stepsize <- (max(space.d) - min(space.d))/nclass
      }
      else {
        nclass <- round((max(space.d) - min(space.d))/stepsize)
      }
    }
    else {
      if (missing(stepsize)) {
        stepsize <- (max(space.d) - min(space.d))/nclass
      }
    }
    breaks <- seq(0, stepsize * nclass, stepsize)
  }
  else {
    nclass <- length(breaks) - 1
  }

  answer.m <- matrix(0, ncol = 7, nrow = nclass * length(alpha))
  dimnames(answer.m) <- list(NULL, c("lag", "ngroup", "mantelr", "pval", "llim", "ulim","dir"))
  answer.m[, 4] <- rep(1, nrow(answer.m))

  for (j in 1:length(ang.breaks)) {
    if (j == 1) {
      amin <- -180
    } else
      amin <- ang.breaks[j - 1]
    amax <- ang.breaks[j]
    space.aclass <- rep(1, length(space.ang))

    space.aclass[space.ang <= amin] <- 0
    space.aclass[space.ang > amax] <- 0
    
    for (i in 1:nclass) {
      row.num <- (j - 1) * nclass + i
      dmin <- breaks[i]
      dmax <- breaks[i + 1]
      answer.m[row.num, 1] <- (dmin + dmax)/2
      space.dclass <- rep(0, length(space.d))
      space.dclass[(space.d * space.aclass) <= dmin] <- 1
      space.dclass[(space.d * space.aclass) > dmax] <- 1
      ngroup <- length(space.dclass) - sum(space.dclass)
      answer.m[row.num, 2] <- ngroup
      if (ngroup > 0) {
        ## For use with the vegan-style mantel():
        space.dmat <- matrix(0, nrow = Nitems, ncol = Nitems)
        space.dmat[lower.tri(space.dmat)] <- space.dclass
        space.dmat[upper.tri(space.dmat)] <- t(space.dmat)[upper.tri(t(space.dmat))]
        answer.m[row.num, 3] <-
          as.numeric(cor.test(space.dclass, species.d, method = "pearson")$estimate)
        if (nperm > 0) {
          N <- nrow(space.dmat)
          perm <- rep(0, nperm)
          for (i in 1:nperm) {
            take <- sample(N)
            permvec <- as.vector(as.dist(space.dmat[take, take]))
            perm[i] <- cor(permvec, species.d, method = "pearson")
          }
          answer.m[row.num, 4] <- ifelse(answer.m[row.num, 3] > 0, sum(perm >= answer.m[row.num, 3])/nperm,
                                         sum(perm <= answer.m[row.num, 3])/nperm)
        }

        #answer.m[row.num, 4] <- mant$signif
        ## For use with the ecodist version of mantel():
        ##         mant <- mantel(species.d ~ space.dclass, nperm = nperm, mrank = mrank, nboot = nboot, pboot = pboot,
        ##                        cboot = cboot)
        ##         answer.m[row.num, 3] <- mant[1]
        ##         if (alternative == "two.sided") 
        ##           answer.m[row.num, 4] <- mant[4]
        ##         else answer.m[row.num, 4] <- mant[2]
        ##         answer.m[row.num, 5] <- mant[5]
        ##         answer.m[row.num, 6] <- mant[6]
      }
      answer.m[row.num,7] <- alpha[j]
      if (trace) 
        cat(i, "\t", answer.m[i, 2], "\t", answer.m[i, 3], 
            "\n")
    }
  }
  
  results <- list(mgram = answer.m, resids = NA)
  class(results) <- "dmgram"
  results
}

`pw.angle` <-
function(xy) {
  res <- numeric((nrow(xy)^2 - nrow(xy))/2)
  tmp <- .C("pwangle", X = as.double(xy[,1]), Y = as.double(xy[,2]), L = as.integer(nrow(xy)), res = as.double(res),
  PACKAGE = "neutral.vp")
  tmp$res[tmp$res < 0] <- 180 + tmp$res[tmp$res < 0]
  mat <- matrix(NA,nrow=nrow(xy), ncol=nrow(xy))
  mat[lower.tri(mat)] <- tmp$res
  return(as.dist(mat))
}

`plot.dmgram` <-
function (x, pval = 0.05, l.cex.text = 1, l.cex.pch = 1, p.cex = 1, ...) {
  x <- x$mgram
  pval.v <- x[, 4]
  ang.v <- x[,7]
  ang.lev <- unique(ang.v)
  ang.num <- length(ang.lev)
  
  plot(x[,1], x[,3], type = 'n', ...)

  fill.syms <- 21:24
  open.syms <- c(22, 1, 2, 5)
  
  for (i in 1:ang.num) {
    points(x[x[,7] == ang.lev[i], 1], x[x[,7] == ang.lev[i], 3], col = i, type = 'l')
    points(x[pval.v <= pval & ang.v == ang.lev[i], 1], x[pval.v <= pval & ang.v == ang.lev[i], 3], pch = fill.syms[i],
           col = i, cex = p.cex, bg = i)
    points(x[pval.v > pval & ang.v == ang.lev[i], 1], x[pval.v > pval & ang.v == ang.lev[i], 3], pch = fill.syms[i], col
           = i, cex = p.cex, bg = 0)
  }

  abline(h=0)

  leg.text <- list()

  for (i in 1:ang.num)
    leg.text <- c(leg.text, substitute(x * degree, list(x = ang.lev[i])))
  
  legend(x = 'bottomleft', legend = do.call("expression", leg.text), pt.cex = l.cex.pch, cex = l.cex.text, pch =
         fill.syms, col = 1:length(ang.lev), pt.bg = 1:length(ang.lev))

  invisible()
  
}

