`habitat.builder` <-
function(N, C) {
  ## N is the number of rows and columns in the matrix, must be even
  ## C is the number of habitat classes, must be an integer factor of N

  if(N %% 2 != 0)
    warning("N is not even, some habitats will not be N x N.\nExpect tragic consequences.") 
  CELLS <- N*N # number of matrix cells
  SUB <- CELLS/C # number of cells in each class
  
  ## gradient:  
  grad <- matrix(rep(1:C, each = N/C), nrow = N, ncol = N)
  grad2 <- t(grad)
  
  ## single hump:
  hump <- matrix(NA, nrow = N, ncol = N)
  for (i in 1:N)
    for (j in 1:N)
      hump[i, j] <- dist(rbind(c(i, j), rep((N+1)/2, 2)))

  hranks <- rank(hump)

  breaks <- rep(SUB, C)
  breaks <- cumsum(breaks)
  
  hump[hranks <= breaks[1] ] <- 1
  for (i in 2:C)
    hump[hranks > breaks[i-1] & hranks <= breaks[i]] <- i

  ## four humps:
  hump4 <- matrix(NA, nrow = N/2, ncol = N/2)
  for (i in 1:N/2)
    for (j in 1:N/2)
      hump4[i, j] <- dist(rbind(c(i, j), rep((N/2 + 1)/2,2)))

  hranks <- rank(hump4)

  breaks <- rep(SUB/4, C)
  breaks <- cumsum(breaks)
  
  hump4[hranks <= breaks[1] ] <- 1
  for (i in 2:C)
    hump4[hranks > breaks[i-1] & hranks <= breaks[i]] <- i

  hump4 <- cbind(hump4, hump4)
  hump4 <- rbind(hump4, hump4)

  ## Waves:
  if (C > N/3)
    Cw <- C/2
  else
    Cw <- C
  wave <- matrix(rep(rep(c(1:Cw, (Cw-1):2), N/Cw)[1:N], N), nrow = N, ncol = N)

  if (Cw == C/2)
    wave <- wave * 2
  
  ## Random:
  rand <- matrix(sample(rep(1:C, each = SUB)), nrow = N, ncol = N)

  return(list(grad = grad, grad2 = grad2, hump = hump, hump4 = hump4, wave = wave, rand = rand))
}

