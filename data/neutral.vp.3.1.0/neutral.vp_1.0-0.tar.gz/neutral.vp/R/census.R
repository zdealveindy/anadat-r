`census` <-
function(sim, snap = length(sim$snaps), type = 'census') {
  pop <- sim$snaps[[snap]]  
  dim(pop) <- c(sim$p$S, sim$p$M, sim$p$M)

  if (type == "census") {
     output <- t(pop[,,1])
  
     for (i in 2:sim$p$M)
       output <- rbind(output, t(pop[,,i]))
   } else if (type == "richness")
     output <- apply(pop, MARGIN = 2:3, FUN = function(x) sum(as.logical(x)))
   else if (type == "abundance")
     output <- apply(pop, MARGIN = 2:3, FUN = sum)
   else
     stop("Invalid type")

  return (output)
}

