.First.lib <- function(lib, pkg)  {
    library.dynam("neutral.vp", pkg, lib)
}


