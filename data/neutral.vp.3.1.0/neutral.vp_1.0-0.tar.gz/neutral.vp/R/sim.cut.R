`sim.cut` <-
function(sim, fact){
  if(min(sim$coords$"X") < 1) 
    sim$coords[,1:2] <- sim$coords[,1:2] + min(sim$coords$"X") + 1

  return(which(sim$coords[,2] %% fact == 0 & sim$coords[,1] %% fact == 0))
}

