`sim.cycle` <-
function(sim, time = 500, cycles = 20) {
  for(i in 1:cycles) {
    cat(paste("Cycle", i, "\n", sep = " "))
    sim <- sim.iter(sim, time)
  }
  return (sim)
}

`sim.init` <-
function(M = 7, K = 500, S = 50, pop = round(rep(K/S, M*M*S)), u = 0.01, d = 0.5, b = 0.505, m = 0.5 * u,
                     habitat = 1, fitness = 1, sel = 1000 - length(unique(fitness)), ef.strength = 0, recruit = 1, fec =
                     1) {

  if(sum(pop) != M^2 * K)
    warning("Cell populations not at carrying capacity")
  
  if (length(habitat) != 1 && length(fitness) != 1) {
    fd <- array(dim = S * M^2)
    dim(fd) <- c(S, M, M)
    for (i in 1:S)
      for (j in 1:M)
        for (k in 1:M)
          fd[i, j, k] <- abs(habitat[j, k] - fitness[i])
    
    fd <- as.vector(fd)
  } else {
    fd <- rep(0, S * M * M)
  }
  
  bv <- (max(fd) + sel - fd)/(max(fd) + sel) * b
  dv <- (sel + fd)/(max(fd) + sel) * d
  
  ef <- recruit - fd * ef.strength
  
  params <- list(K = K, M = M, S = S, u = u, dv = dv, bv = bv, m = m, habitat = habitat, fitness = fitness, sel = sel,
                 ef = ef, fec = fec)

  X <- NULL
  Y <- NULL
  
  coords <- cbind(X = rep(1:M, each = M), Y = rep(1:M, M))
  ##  coords <- scale(coords, center = TRUE, scale = FALSE)
  coords <- transform(coords, "XY" = X*Y, "Xe2" = X^2, "Ye2" = Y^2, "Xe2Y" = X^2 * Y, "XYe2" = X * Y^2, "Xe3" = X^3,
                      "Ye3" = Y^3)

  ret <- list(p = params, coords = coords, snaps = list("0" = pop))
  class(ret) <- "sim"
  return(ret)
}

`sim.iter` <-
function(sim, time) {
  nb = rep(0, sim$p$M * sim$p$M * sim$p$S)
  prelength <- length(sim$snaps)
  pretime <- as.numeric(names(sim$snaps)[prelength])
  
  tmp <- .C("smith08b", M = as.integer(sim$p$M), K = as.integer(sim$p$K), S = as.integer(sim$p$S), pop =
            as.integer(sim$snaps[[prelength]]), nb = as.integer(nb), u = as.double(sim$p$u), dv =
            as.double(sim$p$dv), bv = as.double(sim$p$bv), m = as.double(sim$p$m), t = as.integer(time), ef =
            as.double(sim$p$ef), as.integer(sim$p$fec), PACKAGE = "neutral.vp")

  sim$snaps[[prelength + 1]] <- tmp$pop
  names(sim$snaps)[prelength + 1] <- as.character(pretime + time)
  return(sim)
}

`neut.simulate` <-
function (M = 7, K = 500, S = 50, pop = round(rep(K/S, M*M*S)), u = 0.01, d = 0.5, b = 0.505, m = 0.5 * u,
                     habitat = 1, fitness = 1, sel = 1000 - length(unique(fitness)), ef.strength = 0, recruit = 1, fec =
                     1, time = 100, cycles = 20) {

  sim <- sim.init(M = M, K = K, S = S, pop = pop, u = u, d = d, b = b, m = m, habitat = habitat, fitness = fitness, sel
                  = sel, ef.strength = ef.strength, recruit = recruit, fec = fec)

  sim <- sim.cycle(sim = sim, time = time, cycles = cycles)

  return(sim)
}

"print.sim" <-
  function (x,  ...) 
{
  N <- length(x$snaps)
  cat(paste(x$p$M, "x", x$p$M, "grid;", x$p$S, "species;", N, "snapshots\n\n"))
  
  if(length(x$p$fitness) == 1) {
    cat("Neutral Model\n\n")
  } else {
    cat(paste("Selection =", x$p$sel, "Fitness range", min(x$p$fitness), ":", max(x$p$fitness), "\n"))
    cat(paste("Environment range", min(x$p$habitat), ":", max(x$p$habitat), "\n\n"))
  }
  
  rich <- numeric(N)
  abund <- numeric(N)
  snaps <- names(x$snaps)
  
  for (i in 1:N) {
    cen <- census(x, i)
    rich[i] <- sum(colSums(cen) > 0)
    abund[i] <- sum(cen)
  }
  
  mat <- cbind(rich, abund)
  row.names(mat) <- snaps
  colnames(mat) <- c("Species Richness", "Total Abundance")
  
  print(mat)
}

"sim.vp" <-
  function(sim, snap = length(sim$snaps), habitat.list = NULL, fact = 1, space = 1:9)
{
  if (is.null(habitat.list) & length(sim$p$habitat) > 1) {
    habitat.list <- list(habitat = sim$p$habitat)
  } else if (is.null(habitat.list) & length(sim$p$habitat) == 1) {
    stop("No habitat provided for neutral sim object: user must provide habitat.list")
  }
  
  ind <- sim.cut(sim, fact)
  
  if (is.character(snap))
    snap <- which(names(sim$snaps) == snap)
  
  N <- length(habitat.list)
  res <- matrix(NA, ncol = 3, nrow = N)
  for (i in 1:N) {
    tmp <- varpart(census(sim, snap)[ind,], as.vector(habitat.list[[i]])[ind], sim$coords[ind, space], transfo =
                   "hellinger")
    res[i,] <- tmp$part$fract$Adj.R.squared
  }
  rownames(res) <- names(habitat.list)
  colnames(res) <- c("[a+b]", "[b+c]", "[a+b+c]")
  res <- cbind(res, "[a]" = res[,3]-res[,2], "[b]" = res[,1]+res[,2]-res[,3], "[c]" = res[,3] - res[,1],
               "[d]" = 1 - res[,3])
  res <- res[,c(3,1,2,4,5,6,7)]
  return (res)
}

"sim.pcnm" <-
  function(sim, fact = 1, snap = length(sim$snaps), perms = 999, alpha.val = 0.05, habitat = NULL)
{
  if(!require(packfor))
    stop(paste("This function requires the packfor package:\n",
               "available from http://biomserv.univ-lyon1.fr/~dray/software.php"))
  ssind <- sim.cut(sim, fact = fact)
  if (is.character(snap))
    snap <- which(names(sim$snaps) == snap)
  com <- census(sim, snap = snap)[ssind,]
  com <- decostand(com, method = "hellinger")
  
  if(is.null(habitat)) {
    env <- list(sim$p$habitat[ssind])
  } else {
    env <- vector("list")
    for (i in 1:length(habitat))
      env[[i]] <- habitat[[i]][ssind]
    names(env) <- names(habitat)
  }
  
  xy <- sim$coords[ssind,]
  xy.d <- dist(xy[,1:2])
  xy.thresh <- sort(unique(xy.d))[2]    ## preserve the two smallest distance classes
  xy.d[xy.d > xy.thresh] <- xy.thresh * 4  
  
  xy.pcoa <- cmdscale(xy.d, k = length(ssind) - 1, eig = TRUE)
  xy.vects <- xy.pcoa$points[,which(xy.pcoa$eig > 0)]
  colnames(xy.vects) <- as.character(which(xy.pcoa$eig > 0))
  
  fs <- forward.sel(com, xy.vects, nperm = 2, alpha = 2, R2thresh = 2, adjR2thresh = 2, R2more = 0)
  fs <- forward.sel(com, xy.vects, nperm = perms, alpha = alpha.val, adjR2thresh = fs$AdjR2Cum[nrow(fs)])
  sel <- as.numeric(fs$variables)
  
  res <- list(com = com, env = env, pcnm = xy.vects[,sel])
  return(res)
}

"pcnm.vp" <-
  function(pcnm)
{
  res <- vector("list")
  for (i in 1:length(pcnm$env))
    res[[i]] <- varpart(pcnm$com, pcnm$env[[i]], pcnm$pcnm)
  names(res) <- names(pcnm$env)
  return(res)
}
